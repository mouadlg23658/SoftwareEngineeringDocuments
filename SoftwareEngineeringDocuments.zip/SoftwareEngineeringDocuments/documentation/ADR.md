# Architecture Decision Records ADR-<NN> — <Titre de la décision>
**Statut : Accepted 
**Date : 2025-01-23
**Décideurs :Mouad El Gholabzouri-Ali Bakkali - Ayoub Lamine
**Contexte projet :Luxury Hotel /Implementation d'un systeme informatique

---

## 1. Contexte
- **Problème / besoin :debordement et difficulte a gerer les reservations 
- **Contraintes :C#, 19 Avril, équipe des programmeurs ,  VS >
- **Forces en présence :optimise et bien structure et planifie, temps de reponse >2s , accessible budgeterement, simple et ludique a utiliser , perte des donne

---

## 2. Décision
> Décrire la décision en 1–3 phrases.
- Nous choisissons : de creer un systeme qui vise a aider le front desk ainsi que la comtabilite pour gerer l'entierete de l'hotel 
- Pour : leur faciliter la tache et gagner human power 

---

## 3. Alternatives considérées
### Option A — <nom>
- **Avantages :** <...>
- **Inconvénients :** <...>

### Option B — <nom>
- **Avantages :** <...>
- **Inconvénients :** <...>

---

## 4. Justification (Pourquoi cette décision ?)
- <raison 1> parceque le marche de l'hotelerie n'est pas sature

---

## 5. Conséquences
### Positives
- gain de beaucoup d'argent en ecoonomisant bcp de travail 

### Négatives / Risques
- risque de perte des donnes 

### Impact sur l’architecture / le code
- <modules touchés, patterns concernés, refactoring prévu>

---

## 6. Plan d’implémentation (court)
notre sitw web est interne et en vente on ne va pas l'implementyer mais plutot le vendre
---

## 7. Validation
- **Comment vérifier que c’est bon ?**
  le systeme doit proposer toutes les features cites dans le srs

---

## 8. Liens
- UML : <lien/nom de fichier>
- Issue/Tâche : <lien>
- Référence : <doc officiel / cours>
