# Cahier des charges (SRS léger) — <Luxury Hotel>
**Équipe : Ali Bakkali- Mouad El Gholazbouri- Ayoub Lamine   
**Date : 2026-01-23  
**Version :** <v0.1 / v1.0>

---

## 1. Contexte & objectif
- **Contexte : Pour creer une application web qui aide les hotels a gerer leurs reservations et leurs planning et leurs simplifier le processus et digitaliser les processus 
- Objectif principal :** faciliter la gestion pour le staff  /  optimiser les efforts humains pour la gestion et eviter les erreurs 
- Parties prenantes : Hotel (Cote admin)  - Client (Cote client)

---

## 2. Portée (Scope)
### 2.1 Inclus (IN)
- IN-1 : Recherche de chambres (dates, nombre de personnes, type de chambre)
- IN-2 : Affichage des disponibilites en temps reel
- IN-3 : Détails des chambres (photos, équipements, prix, conditions)
- IN-4 : Modification ou annulation de réservation
- IN-5 : Compte utilisateur (historique des réservations)
- IN-6 : Avis et notes
- IN-7 : Tableau des réservations
- IN-8 : Check-in / Check-out
- IN-9 : Attribution des chambres
- IN-10: Statut des chambres (libre, occupée, nettoyage)
- IN-11: Reservation en ligne 
- IN-12: Service de chambre (petit dejeuner , transport , conciergerie, service groom)
- IN_13: Complementaire (Mini bar, spa ,BarberShop) 

  


### 2.2 Exclu (OUT)
- OUT-1 : Paiement sécurise
- OUT-2 : Confirmation automatique (email / notification)
- OUT-3 :
- OUT-4 :


## 3. Acteurs / profils utilisateurs
- Receptionniste : Faire les check ins/out, entrer infos clients, modifier les reservations.
- Client : Reserver , choisir les complements. 

---

## 4. Exigences fonctionnelles (FR)
> Forme recommandée : “Le système doit…”
- FR-1 : Le système doit etre capable de booker des chambres , de modfier les dates ou types de chambres des reservations.
- FR-2 : Le système doit etre capable d'afficher les disponibilites 

---

## 5. Exigences non fonctionnelles (NFR)
> Performance / sécurité / disponibilité / UX / maintenabilité…
- **NFR-1 (Performance) :temps de reponse 5s
- **NFR-2 (Sécurité) :double authentification
- **NFR-4 (Qualité) :resistible au attaque brut force ou injection SQL

---

## 6. Contraintes
- **C-1 (Technologie) :c# html/css sql asp.net
- **C-2 (Plateforme) : web
- **C-3 (Délai) : date limite 19 avril
- **C-4 (Outils) :Git

---

## 7. Données & règles métier (si applicable)
- **Entités principales :** <User, Order, ...>
- **Règles métier :calcul du prix total et des taxes , verification d'age pour consommation d'alcool , verification d'entree ID 
---

## 8. Hypothèses & dépendances
### 8.1 Hypothèses
- H-1 : utilisateur cree un compte et devient donc un client
- H-2 : Le client peut faire une reservation , choisir le type de chambre , changer la date et le type de chambre selon la disponibilites
- H-3 : Admin peut checker et gerer la base de donnes des chambres 

### 8.2 Dépendances
- D-1 :BD / visual studio

---

## 9. Critères d’acceptation globaux (Definition of Done – mini)
- [ ] Fonctionnalités livrées et testées
- [ ] Tests unitaires présents
- [ ] Gestion d’erreurs minimale
- [ ] Documentation à jour (UML + ADR si requis)
